package com.mycompany.gestione_contocorrente;

public class ContoCorrente {
    
    private String Iban;
    private float Saldo = 0;
    private float Canone;
    private float[] Movimenti = new float[100];
    private int i = 0; // Contatore dei movimenti effettivi inseriti
    
    public ContoCorrente(String Iban, float Canone) {
        this.Iban = Iban;
        this.Canone = Canone;
    }
    
    public boolean Versamento(float importo) {
        // Controllo importo positivo e spazio disponibile nell'array
        if (importo <= 0 || i >= Movimenti.length) {
            return false;
        }
        Saldo = Saldo + importo;
        Movimenti[i] = importo;
        i++;
        return true;
    }
    
    public boolean Prelievo(float importo) {
        // Controllo importo positivo, saldo sufficiente e spazio nell'array
        if (importo <= 0 || Saldo < importo || i >= Movimenti.length) {
            return false;
        }
        Saldo = Saldo - importo;
        Movimenti[i] = -importo;
        i++;
        return true;
    }
    
    public float getSaldo() {
        return Saldo;
    }
    
    public float[] getMovimenti() {
        return Movimenti;
    }
    
    public String MovimentiToString() {
        String S = "Movimenti\n------------\n";
        
        for (int k = 0; k < i; k++) {
            if (Movimenti[k] > 0) {
                S += "+" + Movimenti[k] + "\n";
            } else {
                S += Movimenti[k] + "\n"; 
            }
        }
        return S;
    }

   
    public float totaleVersamenti() {
        float totale = 0;
        for (int k = 0; k < i; k++) {
            if (Movimenti[k] > 0) {
                totale += Movimenti[k];
            }
        }
        return totale;
    }

   
    public float totalePrelievi() {
        float totale = 0;
        for (int k = 0; k < i; k++) {
            if (Movimenti[k] < 0) {
                totale += -Movimenti[k]; 
            }
        }
        return totale;
    }

   
    public int numeroVersamenti() {
        int conta = 0;
        for (int k = 0; k < i; k++) {
            if (Movimenti[k] > 0) {
                conta++;
            }
        }
        return conta;
    }

  
    public int numeroPrelievi() {
        int conta = 0;
        for (int k = 0; k < i; k++) {
            if (Movimenti[k] < 0) {
                conta++;
            }
        }
        return conta;
    }

  
    public float versamentoMedio() {
        int num = numeroVersamenti();
        if (num == 0) {
            return 0;
        }
        return totaleVersamenti() / num;
    }

   
    public float prelievoMedio() {
        int num = numeroPrelievi();
        if (num == 0) {
            return 0;
        }
        return totalePrelievi() / num;
    }

  
    public float versamentoPiuAlto() {
        float max = 0;
        for (int k = 0; k < i; k++) {
            if (Movimenti[k] > 0 && Movimenti[k] > max) {
                max = Movimenti[k];
            }
        }
        return max;
    }

   
    public float prelievoPiuAlto() {
        float max = 0;
        for (int k = 0; k < i; k++) {
            if (Movimenti[k] < 0 && (-Movimenti[k]) > max) {
                max = -Movimenti[k];
            }
        }
        return max;
    }
    
    
    public void stampaStatistiche() {
        System.out.println("--- STATISTICHE DEL CONTO ---");
        System.out.println("Totale versamenti: " + totaleVersamenti() + " euro");
        System.out.println("Totale prelievi: " + totalePrelievi() + " euro");
        System.out.println("Numero versamenti: " + numeroVersamenti());
        System.out.println("Numero prelievi: " + numeroPrelievi());
        System.out.println("Versamento medio: " + versamentoMedio() + " euro");
        System.out.println("Prelievo medio: " + prelievoMedio() + " euro");
        System.out.println("Versamento più alto: " + versamentoPiuAlto() + " euro");
        System.out.println("Prelievo più alto: " + prelievoPiuAlto() + " euro");
    }
}