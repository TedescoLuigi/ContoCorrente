/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.gestione_contocorrente;

/**
 *
 * @author luigitedesco
 */
public class Gestione_ContoCorrente {

    public static void main(String[] args) {
       
        ContoCorrente c1 = new ContoCorrente("IT60X0542811101000000123456", 12);

        
        c1.Versamento(200);
        c1.Prelievo(50);
        c1.Versamento(100);
        c1.Prelievo(30);

      
        System.out.print(c1.MovimentiToString());
        System.out.println("Saldo attuale: " + c1.getSaldo() + " euro\n");

        
        c1.stampaStatistiche();
    }
}