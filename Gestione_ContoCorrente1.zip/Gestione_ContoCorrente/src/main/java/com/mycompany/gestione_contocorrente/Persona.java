/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.gestione_contocorrente;

/**
 *
 * @author tedesco.luigi
 */
public class Persona {
    
        private String Nome;
        String Cognome;
        String DataNascita;
        String CodiceFiscale;
        String CodiceDocumento ;
        String Sesso;

    public Persona(String Nome, String Cognome, String DataNascita, String CodiceFiscale, String CodiceDocumento, String Sesso) {
        this.Nome = Nome;
        this.Cognome = Cognome;
        this.DataNascita = DataNascita;
        this.CodiceFiscale = CodiceFiscale;
        this.CodiceDocumento = CodiceDocumento;
        this.Sesso = Sesso;
    }
    
  
    public String getNome()
    {
        return Nome;
    }
    public String getCognome()
    {
        return Cognome;
    }
    
    
    
    
    
}
