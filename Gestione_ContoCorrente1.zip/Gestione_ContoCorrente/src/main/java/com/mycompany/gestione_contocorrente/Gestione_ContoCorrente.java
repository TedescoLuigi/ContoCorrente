/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.gestione_contocorrente;

/**
 *
 * @author luigitedesco
 */
public class Gestione_ContoCorrente {

    public static void main(String[] args) {
       
        Persona p1 = new Persona ("Luigi","Tedesco","2009/01/30","TDSLGU09A30C745W","CA43298US","Maschio");
        ContoCorrente c1 = new ContoCorrente("IT60X05428111010000001783456", 12 , 200, p1);
        

        c1.Versamento(200);
        c1.Prelievo(50);
        c1.Versamento(100);
        c1.Prelievo(30);

      
        System.out.print(c1.MovimentiToString());
        System.out.println("Saldo attuale: " + c1.getSaldo() + " euro\n");

        //stampare documento partendo dal conto
        String doc = c1.
        
        c1.stampaStatistiche();
    }
}